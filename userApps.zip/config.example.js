module.exports = {
    token: '<BOT_TOKEN>',
    owners: ['<YOUR_ID>'],
    mongo: '<MONGO_URI>'
}