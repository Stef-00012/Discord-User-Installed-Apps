module.exports = {
    token: 'MTIxOTU3NDYwNjI5NDQxNzQ5OQ.GMry2n.TAyFlcPqg6BrZaTKAHQC29xm-XRMRM0OZx84Bg',
    owners: ['694986201739952229'],
    mongo: 'mongodb://Stef:igk46LSCo2Cd4L9XQSo@194.60.201.37:30004/?retryWrites=true&w=majority'
}